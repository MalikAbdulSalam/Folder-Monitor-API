# using flask_restful
from flask import Flask, jsonify, request,send_from_directory,send_file
from flask_restful import Resource, Api
import os
import zipfile
import configparser
import glob
from flask_caching import Cache
import subprocess


root=os.path.expanduser('~')
# creating the flask app
app = Flask(__name__)

# creating an API object
api = Api(app)

class Hello(Resource):

	def get(self):

		return jsonify({'message': 'maa sha Allah'})

	# Corresponds to POST request
	def post(self):
		
		data = request.get_json()
		return jsonify({'data': data}), 201

class files(Resource):

	def get(self):
		# os.remove("results.zip")
		parser = configparser.ConfigParser()
		zipfolder = zipfile.ZipFile('results.zip', 'w', compression=zipfile.ZIP_STORED)  # Compression type
		result_paths = glob.glob('./results/*')
		for ll in result_paths:
			zipfolder.write(ll)
		zipfolder.close()


		return send_file('./results.zip',
						 mimetype='zip',
						 as_attachment=True)

api.add_resource(Hello, '/')
api.add_resource(files, '/files')




# driver function
if __name__ == '__main__':

	app.run(host='0.0.0.0',port = "8000" , debug = True, threaded = True)
	#cache.init_app(app)
