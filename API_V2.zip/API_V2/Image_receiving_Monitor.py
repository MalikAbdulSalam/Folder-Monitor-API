from time import sleep
import os
import glob
import subprocess

while 1:
	received_images_list = os.listdir('./Image_receiving_folder/')
	print("Quantity ", len(received_images_list),"Files received")
	if len(received_images_list) > 0:
		print("")
		print("   ***************      ***************       *****         ***************      ***************")
		print("   ***************      ***************      **    **       ***************      ***************")
		print("   **                         **           **      **       **           **            **")
		print("   **                         **          **        **      **           **            **")
		print("   **                         **         **          **     **           **            **")
		print("   ***************            **         **************     ***************            **")
		print("   ***************            **         **************     ***************            **")
		print("                **            **         **          **     **       **                **")
		print("                **            **         **          **     **        **               **")
		print("                **            **         **          **     **         **              **")
		print("   ***************            **         **          **     **          **             **")
		print("   ***************            **         **          **     **           ***           **")
		print("")
		print("Your script execution is in process..... Please wait")
		result = subprocess.run(["python", "./Model.py"], capture_output=True, text=True)
		print("script executed successfully")
		for received_image in glob.glob('./Image_receiving_folder/*'):
			os.remove(received_image)
			print("File receiving folder is empty now")
	sleep(1)
